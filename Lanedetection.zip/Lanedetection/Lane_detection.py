import cv2
import numpy as np
import time

# Function to find region of interest
def region_of_interest(img, vertices):
    mask = np.zeros_like(img)
    match_mask_color = 255
    cv2.fillPoly(mask, vertices, match_mask_color)
    masked_image = cv2.bitwise_and(img, mask)
    return masked_image

# Function to draw the lines
def draw_the_lines(img, lines):
    img = np.copy(img)
    if lines is not None:
        blank_image = np.zeros((img.shape[0], img.shape[1], 3), dtype=np.uint8)
        for line in lines:
            for x1, y1, x2, y2 in line:
                cv2.line(blank_image, (x1, y1), (x2, y2), (0, 255, 0), thickness=2)
        img = cv2.addWeighted(img, 0.9, blank_image, 1, 0.0)
    return img

# Function to process each frame
def process(frame):
    height = frame.shape[0]
    width = frame.shape[1]
    roi_bottom_left = (width // 8, height)
    roi_top_left = (width // 2 - width // 40, height // 2 + height // 10)
    roi_top_right = (width // 2 + width // 15, height // 2 + height // 10)
    roi_bottom_right = (width - width // 8, height)
    region_of_interest_vertices = np.array([[roi_bottom_left, roi_top_left, roi_top_right, roi_bottom_right]], dtype=np.int32)

    gray_image = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    canny_image = cv2.Canny(gray_image, 350, 350)
    cropped_image = region_of_interest(canny_image, region_of_interest_vertices)

    lines = cv2.HoughLinesP(cropped_image, rho=8, theta=np.pi/180, threshold=80, lines=np.array([]), minLineLength=5, maxLineGap=5)
    image_with_lines = draw_the_lines(frame, lines)

    # Get current time
    current_time = time.strftime("%H:%M:%S", time.localtime())

    # Display time on frame
    cv2.putText(image_with_lines, current_time, (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

    return image_with_lines

cap = cv2.VideoCapture('/Users/jay_vaghasiya/opencv-python-4.5.3.56/Python_OpenCv/Lanedetection/video01.mp4')

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    frame = process(frame)
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
